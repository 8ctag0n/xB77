# Análisis Extremo: Pipeline ZK y Verificación Criptográfica

## Estado Actual
Dimos un salto cualitativo al reemplazar el "Mock Judge" por un **Verificador Groth16 Real** en `onchain/programs/xb77_zk_verifier/src/lib.rs`.

**El Logro:**
1. Integramos `verifier-lib` (Sunspot).
2. Definimos la estructura de la **Verifying Key (VK)**.
3. Implementamos la des-serialización de la prueba (Proof) y el testigo (Witness) directamente desde el buffer on-chain.

## El Problema del Tamaño y el Cómputo
Verificar SNARKs en Solana (BN254) es intensivo en Compute Units (CU). Una prueba Groth16 estándar requiere operaciones de pairing que empujan los límites del runtime BPF de Solana.

**Estrategia Edge (El "Paradigma Cloudflare"):**
El roadmap apunta a una optimización radical: **Verification-only on Worker**.
Generar una prueba Noir puede tomar segundos y mucha RAM, pero verificarla en Wasm (dentro de Cloudflare) toma `< 50ms`.

La arquitectura final debe ser:
1. **Prover (Cliente/Z-Node):** Ejecuta `nargo prove` y genera `zk_receipt.proof`.
2. **Gateway (Edge):** Recibe la prueba. El JS invoca la verificación Wasm. Si pasa, actualiza la base de datos (D1/KV) e inyecta la confirmación.
3. **Solana (Opcional/Batch):** Solo se asientan en L1 los "Merkle Roots" de lotes (batches) ya verificados por el Edge, ahorrando miles de dólares en fees de L1.

## Próximo Obstáculo
Necesitamos generar un circuito Noir real para `zk_receipt` (usando `nargo`), compilarlo, extraer la VK real e inyectarla en nuestro código Zig/Rust. Actualmente, los arrays de la VK en `vk.rs` son stubs (`[0x01; 64]`).
