# Análisis Extremo: Arquitectura de Runtime y Orquestación

## Estado Actual
Hemos realizado una transición crítica de una arquitectura basada puramente en contenedores (Podman/Docker) a una **orquestación nativa** mediante `Makefile.native`. 

**Beneficios inmediatos:**
1. **Developer Experience (DX):** Tiempos de iteración reducidos a milisegundos.
2. **Observabilidad:** Posibilidad de atachar debuggers (`gdb`/`lldb`) directamente a los procesos de Zig y Rust sin atravesar capas de virtualización.
3. **Frontend Real:** Se eliminó la dependencia de datos hardcodeados (mock). El frontend ahora consume la API real del Worker en `http://localhost:8787`.

## El Cuello de Botella: El Puente Zig-to-Wasm
El Gateway actual está escrito en JavaScript (`index.js`), pero el "cerebro" y la lógica de consenso están en Zig (`core/`). Para lograr el roadmap de Cloudflare, comenzamos a despojar a `gateway/main.zig` de sus dependencias de red (`std.net`, hilos) para hacerlo compatible con `wasm32-freestanding`.

**Desafío Técnico:**
Cloudflare Workers impone límites estrictos. No hay `libc` nativa, no hay hilos del SO.
La solución implementada (y que debe profundizarse) es el uso de un **Linear Memory Allocator** compartido:
1. El JS asigna memoria usando `export fn alloc()`.
2. El JS escribe el input (ej. transacción o prompt).
3. El JS invoca `export fn ask()`.
4. Zig procesa y devuelve un puntero a la respuesta.
5. El JS lee la respuesta y llama a `export fn dealloc()`.

## Siguientes Pasos Arquitectónicos
1. **Completar la migración Wasm:** Aislar completamente el motor soberano en Zig para que compile a un `.wasm` de < 1MB.
2. **Inversión de Control (Ingesta):** Actualmente, el Gateway es un servidor pasivo. Debe convertirse en un cliente activo que haga `fetch` (vía Cron Triggers de Cloudflare) al Z-Node o al RPC de Solana para mantener sus KV stores sincronizados, logrando el 100% de uptime requerido.
