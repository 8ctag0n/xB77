var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// src/index.js
import wasmModule from "./a0c87970c0ea7ff4ef10670f62d095a2be7c4ed5-gateway.wasm";
function fromHex(s) {
  if (!s || s.length % 2 !== 0) return null;
  const out = new Uint8Array(s.length / 2);
  for (let i = 0; i < out.length; i++) {
    out[i] = parseInt(s.slice(i * 2, i * 2 + 2), 16);
  }
  return out;
}
__name(fromHex, "fromHex");
function toHex(b) {
  return Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
}
__name(toHex, "toHex");
function u64beBytes(n) {
  const out = new Uint8Array(8);
  let bn = BigInt(n);
  for (let i = 7; i >= 0; i--) {
    out[i] = Number(bn & 0xffn);
    bn >>= 8n;
  }
  return out;
}
__name(u64beBytes, "u64beBytes");
var PKCS8_PREFIX = new Uint8Array([48, 46, 2, 1, 0, 48, 5, 6, 3, 43, 101, 112, 4, 34, 4, 32]);
async function importGatewayPriv(privHex) {
  const bytes = fromHex(privHex);
  const seed = bytes.slice(0, 32);
  const pkcs8 = new Uint8Array(PKCS8_PREFIX.length + 32);
  pkcs8.set(PKCS8_PREFIX);
  pkcs8.set(seed, PKCS8_PREFIX.length);
  const key = await crypto.subtle.importKey("pkcs8", pkcs8, "Ed25519", false, ["sign"]);
  return { signKey: key, pubkey: bytes.slice(32, 64) };
}
__name(importGatewayPriv, "importGatewayPriv");
var src_default = {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;
    const kv_cache = /* @__PURE__ */ new Map();
    const effects = [];
    const pkHex = request.headers.get("X-Xb77-Pubkey");
    if (pkHex) {
      const pkBytes2 = fromHex(pkHex);
      if (pkBytes2) {
        const hash = await crypto.subtle.digest("SHA-256", pkBytes2);
        const agent_id = "ag_" + toHex(new Uint8Array(hash).slice(0, 9));
        const agentData = await env.AGENTS.get(`agent:${agent_id}`);
        if (agentData) kv_cache.set(`agent:${agent_id}`, agentData);
        const nonceHex = request.headers.get("X-Xb77-Nonce");
        if (nonceHex) {
          const nonceKey = `nonce:${agent_id}:${nonceHex}`;
          const seen = await env.NONCES.get(nonceKey);
          if (seen) kv_cache.set(nonceKey, seen);
        }
      }
    }
    const wasi_shim = {
      fd_write: /* @__PURE__ */ __name((fd, iovs, iovs_len, nwritten) => 0, "fd_write"),
      fd_close: /* @__PURE__ */ __name((fd) => 0, "fd_close"),
      fd_seek: /* @__PURE__ */ __name((fd, offset_low, offset_high, whence, new_offset) => 0, "fd_seek"),
      proc_exit: /* @__PURE__ */ __name((code) => {
      }, "proc_exit"),
      args_sizes_get: /* @__PURE__ */ __name((argc, argv_buf_size) => 0, "args_sizes_get"),
      args_get: /* @__PURE__ */ __name((argv, argv_buf) => 0, "args_get"),
      environ_sizes_get: /* @__PURE__ */ __name((env_count, env_buf_size) => 0, "environ_sizes_get"),
      environ_get: /* @__PURE__ */ __name((env2, env_buf) => 0, "environ_get"),
      clock_time_get: /* @__PURE__ */ __name((id, precision, time_out) => 0, "clock_time_get"),
      fd_read: /* @__PURE__ */ __name((fd, iovs, iovs_len, nread) => 0, "fd_read"),
      fd_pread: /* @__PURE__ */ __name((fd, iovs, iovs_len, offset, nread) => 0, "fd_pread"),
      fd_write: /* @__PURE__ */ __name((fd, iovs, iovs_len, nwritten) => 0, "fd_write"),
      fd_pwrite: /* @__PURE__ */ __name((fd, iovs, iovs_len, offset, nwritten) => 0, "fd_pwrite"),
      fd_close: /* @__PURE__ */ __name((fd) => 0, "fd_close"),
      fd_seek: /* @__PURE__ */ __name((fd, offset_low, offset_high, whence, new_offset) => 0, "fd_seek"),
      fd_filestat_get: /* @__PURE__ */ __name((fd, buf) => 0, "fd_filestat_get"),
      fd_fdstat_get: /* @__PURE__ */ __name((fd, buf) => 0, "fd_fdstat_get"),
      fd_prestat_get: /* @__PURE__ */ __name((fd, buf) => 8, "fd_prestat_get"),
      fd_prestat_dir_name: /* @__PURE__ */ __name((fd, path2, path_len) => 8, "fd_prestat_dir_name"),
      path_open: /* @__PURE__ */ __name((fd, dirflags, path2, path_len, oflags, fs_rights_base, fs_rights_inheriting, fdflags, opened_fd) => 8, "path_open"),
      path_filestat_get: /* @__PURE__ */ __name((fd, flags, path2, path_len, buf) => 8, "path_filestat_get"),
      proc_exit: /* @__PURE__ */ __name((code) => {
      }, "proc_exit"),
      random_get: /* @__PURE__ */ __name((buf, len) => {
        crypto.getRandomValues(new Uint8Array(instance.exports.memory.buffer, buf, len));
        return 0;
      }, "random_get")
    };
    const instance = await WebAssembly.instantiate(wasmModule, {
      wasi_snapshot_preview1: wasi_shim,
      env: {
        js_kv_get: /* @__PURE__ */ __name((ptr, len) => {
          const key = new TextDecoder().decode(new Uint8Array(instance.exports.memory.buffer, ptr, len));
          const val = kv_cache.get(key);
          if (!val) return 0;
          return copyToWasm(instance, new TextEncoder().encode(val));
        }, "js_kv_get"),
        js_kv_get_len: /* @__PURE__ */ __name((ptr, len) => {
          const key = new TextDecoder().decode(new Uint8Array(instance.exports.memory.buffer, ptr, len));
          const val = kv_cache.get(key);
          return val ? val.length : 0;
        }, "js_kv_get_len"),
        js_kv_put: /* @__PURE__ */ __name((kPtr, kLen, vPtr, vLen, ttl) => {
          const key = new TextDecoder().decode(new Uint8Array(instance.exports.memory.buffer, kPtr, kLen));
          const val = new TextDecoder().decode(new Uint8Array(instance.exports.memory.buffer, vPtr, vLen));
          effects.push({ type: "kv_put", key, val, ttl });
        }, "js_kv_put"),
        js_telegram_send: /* @__PURE__ */ __name((chat_id, ptr, len) => {
          const text = new TextDecoder().decode(new Uint8Array(instance.exports.memory.buffer, ptr, len));
          effects.push({ type: "telegram", chat_id, text });
        }, "js_telegram_send"),
        js_fly_spawn: /* @__PURE__ */ __name((ptr, len) => {
          const agent_id = new TextDecoder().decode(new Uint8Array(instance.exports.memory.buffer, ptr, len));
          effects.push({ type: "fly_spawn", agent_id });
        }, "js_fly_spawn"),
        js_rpc_call: /* @__PURE__ */ __name((mPtr, mLen, pPtr, pLen) => {
          const method2 = new TextDecoder().decode(new Uint8Array(instance.exports.memory.buffer, mPtr, mLen));
          const params = new TextDecoder().decode(new Uint8Array(instance.exports.memory.buffer, pPtr, pLen));
          const cacheKey = `rpc:${method2}:${params}`;
          const cached = kv_cache.get(cacheKey) || '{"result":0}';
          const bytes = new TextEncoder().encode(cached + "\0");
          return copyToWasm(instance, bytes);
        }, "js_rpc_call"),
        js_now: /* @__PURE__ */ __name(() => BigInt(Date.now()), "js_now")
      }
    });
    if (path === "/api/v1/network/pulse") {
      try {
        const rpcResp = await fetch(env.ZNODE_RPC_URL, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "getSlot", params: [] })
        });
        const rpcJson = await rpcResp.text();
        kv_cache.set("rpc:getSlot:[]", rpcJson);
      } catch (e) {
      }
    } else if (path === "/api/v1/actions/register_agent" && pkHex) {
      try {
        const rpcResp = await fetch(env.ZNODE_RPC_URL, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "getBalance", params: [pkHex] })
        });
        const rpcJson = await rpcResp.text();
        kv_cache.set(`rpc:getBalance:${pkHex}`, rpcJson);
      } catch (e) {
      }
    }
    for (const [k, v] of kv_cache) {
      const kBytes = new TextEncoder().encode(k);
      const vBytes = new TextEncoder().encode(v);
      const kPtr = copyToWasm(instance, kBytes);
      const vPtr = copyToWasm(instance, vBytes);
      instance.exports.inject_kv_cache(kPtr, kBytes.length, vPtr, vBytes.length);
    }
    const body = new Uint8Array(await request.arrayBuffer());
    const methodBytes = new TextEncoder().encode(method);
    const pathBytes = new TextEncoder().encode(path);
    const pkBytes = fromHex(pkHex || "") || new Uint8Array(0);
    const sigBytes = fromHex(request.headers.get("X-Xb77-Signature") || "") || new Uint8Array(0);
    const nonceBytes = fromHex(request.headers.get("X-Xb77-Nonce") || "") || new Uint8Array(0);
    const ts = BigInt(request.headers.get("X-Xb77-Timestamp") || "0");
    const idempBytes = new TextEncoder().encode(request.headers.get("X-Idempotency-Key") || "");
    const respPtr = instance.exports.handle_request(
      copyToWasm(instance, methodBytes),
      methodBytes.length,
      copyToWasm(instance, pathBytes),
      pathBytes.length,
      copyToWasm(instance, body),
      body.length,
      copyToWasm(instance, new TextEncoder().encode(pkHex || "")),
      (pkHex || "").length,
      copyToWasm(instance, new TextEncoder().encode(request.headers.get("X-Xb77-Signature") || "")),
      (request.headers.get("X-Xb77-Signature") || "").length,
      ts,
      copyToWasm(instance, new TextEncoder().encode(request.headers.get("X-Xb77-Nonce") || "")),
      (request.headers.get("X-Xb77-Nonce") || "").length,
      copyToWasm(instance, idempBytes),
      idempBytes.length
    );
    const view = new DataView(instance.exports.memory.buffer);
    const status = view.getInt32(respPtr, true);
    const bodyPtr = view.getUint32(respPtr + 4, true);
    const bodyLen = view.getUint32(respPtr + 8, true);
    const actionByte = view.getUint8(respPtr + 12);
    const shouldSign = view.getUint8(respPtr + 13) !== 0;
    const respBody = new Uint8Array(instance.exports.memory.buffer, bodyPtr, bodyLen);
    const finalBody = new Uint8Array(respBody);
    for (const effect of effects) {
      if (effect.type === "kv_put") {
        const ns = effect.key.startsWith("agent:") ? env.AGENTS : effect.key.startsWith("nonce:") ? env.NONCES : env.AGENTS;
        await ns.put(effect.key, effect.val, effect.ttl ? { expirationTtl: effect.ttl } : {});
      } else if (effect.type === "telegram") {
        ctx.waitUntil(sendTelegram(effect.chat_id, effect.text, env));
      }
    }
    const headers = {
      "content-type": "application/json",
      "access-control-allow-origin": env.ALLOWED_ORIGIN || "*",
      "access-control-allow-headers": "*",
      "access-control-expose-headers": "*"
    };
    if (shouldSign) {
      const gatewayKeys = await importGatewayPriv(env.GATEWAY_PRIVKEY_HEX || env.GATEWAY_PRIVKEY_HEX_DEV);
      const respTs = Date.now();
      const canonical = new Uint8Array(1 + 8 + finalBody.length);
      canonical[0] = actionByte;
      canonical.set(u64beBytes(respTs), 1);
      canonical.set(finalBody, 9);
      const sigBuf = await crypto.subtle.sign("Ed25519", gatewayKeys.signKey, canonical);
      headers["x-xb77-gateway-timestamp"] = String(respTs);
      headers["x-xb77-gateway-signature"] = toHex(new Uint8Array(sigBuf));
    }
    return new Response(finalBody, { status, headers });
  }
};
function copyToWasm(instance, data) {
  if (data.length === 0) return 0;
  const ptr = instance.exports.alloc(data.length);
  if (ptr === 0) throw new Error("WASM alloc failed");
  const mem = new Uint8Array(instance.exports.memory.buffer);
  mem.set(data, ptr);
  return ptr;
}
__name(copyToWasm, "copyToWasm");
async function sendTelegram(chat_id, text, env) {
  if (!env.TELEGRAM_TOKEN) return;
  const url = `https://api.telegram.org/bot${env.TELEGRAM_TOKEN}/sendMessage`;
  await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ chat_id, text, parse_mode: "HTML" })
  });
}
__name(sendTelegram, "sendTelegram");

// ../../../../tmp/bunx-0-wrangler@latest/node_modules/wrangler/templates/middleware/middleware-ensure-req-body-drained.ts
var drainBody = /* @__PURE__ */ __name(async (request, env, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env);
  } finally {
    try {
      if (request.body !== null && !request.bodyUsed) {
        const reader = request.body.getReader();
        while (!(await reader.read()).done) {
        }
      }
    } catch (e) {
      console.error("Failed to drain the unused request body.", e);
    }
  }
}, "drainBody");
var middleware_ensure_req_body_drained_default = drainBody;

// ../../../../tmp/bunx-0-wrangler@latest/node_modules/wrangler/templates/middleware/middleware-miniflare3-json-error.ts
function reduceError(e) {
  return {
    name: e?.name,
    message: e?.message ?? String(e),
    stack: e?.stack,
    cause: e?.cause === void 0 ? void 0 : reduceError(e.cause)
  };
}
__name(reduceError, "reduceError");
var jsonError = /* @__PURE__ */ __name(async (request, env, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env);
  } catch (e) {
    const error = reduceError(e);
    return Response.json(error, {
      status: 500,
      headers: { "MF-Experimental-Error-Stack": "true" }
    });
  }
}, "jsonError");
var middleware_miniflare3_json_error_default = jsonError;

// .wrangler/tmp/bundle-u4tEmJ/middleware-insertion-facade.js
var __INTERNAL_WRANGLER_MIDDLEWARE__ = [
  middleware_ensure_req_body_drained_default,
  middleware_miniflare3_json_error_default
];
var middleware_insertion_facade_default = src_default;

// ../../../../tmp/bunx-0-wrangler@latest/node_modules/wrangler/templates/middleware/common.ts
var __facade_middleware__ = [];
function __facade_register__(...args) {
  __facade_middleware__.push(...args.flat());
}
__name(__facade_register__, "__facade_register__");
function __facade_invokeChain__(request, env, ctx, dispatch, middlewareChain) {
  const [head, ...tail] = middlewareChain;
  const middlewareCtx = {
    dispatch,
    next(newRequest, newEnv) {
      return __facade_invokeChain__(newRequest, newEnv, ctx, dispatch, tail);
    }
  };
  return head(request, env, ctx, middlewareCtx);
}
__name(__facade_invokeChain__, "__facade_invokeChain__");
function __facade_invoke__(request, env, ctx, dispatch, finalMiddleware) {
  return __facade_invokeChain__(request, env, ctx, dispatch, [
    ...__facade_middleware__,
    finalMiddleware
  ]);
}
__name(__facade_invoke__, "__facade_invoke__");

// .wrangler/tmp/bundle-u4tEmJ/middleware-loader.entry.ts
var __Facade_ScheduledController__ = class ___Facade_ScheduledController__ {
  constructor(scheduledTime, cron, noRetry) {
    this.scheduledTime = scheduledTime;
    this.cron = cron;
    this.#noRetry = noRetry;
  }
  static {
    __name(this, "__Facade_ScheduledController__");
  }
  #noRetry;
  noRetry() {
    if (!(this instanceof ___Facade_ScheduledController__)) {
      throw new TypeError("Illegal invocation");
    }
    this.#noRetry();
  }
};
function wrapExportedHandler(worker) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return worker;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  const fetchDispatcher = /* @__PURE__ */ __name(function(request, env, ctx) {
    if (worker.fetch === void 0) {
      throw new Error("Handler does not export a fetch() function.");
    }
    return worker.fetch(request, env, ctx);
  }, "fetchDispatcher");
  return {
    ...worker,
    fetch(request, env, ctx) {
      const dispatcher = /* @__PURE__ */ __name(function(type, init) {
        if (type === "scheduled" && worker.scheduled !== void 0) {
          const controller = new __Facade_ScheduledController__(
            Date.now(),
            init.cron ?? "",
            () => {
            }
          );
          return worker.scheduled(controller, env, ctx);
        }
      }, "dispatcher");
      return __facade_invoke__(request, env, ctx, dispatcher, fetchDispatcher);
    }
  };
}
__name(wrapExportedHandler, "wrapExportedHandler");
function wrapWorkerEntrypoint(klass) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return klass;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  return class extends klass {
    #fetchDispatcher = /* @__PURE__ */ __name((request, env, ctx) => {
      this.env = env;
      this.ctx = ctx;
      if (super.fetch === void 0) {
        throw new Error("Entrypoint class does not define a fetch() function.");
      }
      return super.fetch(request);
    }, "#fetchDispatcher");
    #dispatcher = /* @__PURE__ */ __name((type, init) => {
      if (type === "scheduled" && super.scheduled !== void 0) {
        const controller = new __Facade_ScheduledController__(
          Date.now(),
          init.cron ?? "",
          () => {
          }
        );
        return super.scheduled(controller);
      }
    }, "#dispatcher");
    fetch(request) {
      return __facade_invoke__(
        request,
        this.env,
        this.ctx,
        this.#dispatcher,
        this.#fetchDispatcher
      );
    }
  };
}
__name(wrapWorkerEntrypoint, "wrapWorkerEntrypoint");
var WRAPPED_ENTRY;
if (typeof middleware_insertion_facade_default === "object") {
  WRAPPED_ENTRY = wrapExportedHandler(middleware_insertion_facade_default);
} else if (typeof middleware_insertion_facade_default === "function") {
  WRAPPED_ENTRY = wrapWorkerEntrypoint(middleware_insertion_facade_default);
}
var middleware_loader_entry_default = WRAPPED_ENTRY;
export {
  __INTERNAL_WRANGLER_MIDDLEWARE__,
  middleware_loader_entry_default as default
};
//# sourceMappingURL=index.js.map
